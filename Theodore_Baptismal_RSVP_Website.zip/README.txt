THEODORE'S BAPTISMAL RSVP WEBSITE

Files:
- index.html — the complete editable website.

Included:
1. Cover page
2. Online RSVP form
3. No Ninang/Ninong section
4. No gift/gift ideas section
5. No reception section
6. No extra baptism details

EDITING:
Open index.html in any text editor. Search for the text you want to change (name, date, wording, etc.).

ONLINE RSVP:
The form is designed to submit to an online endpoint. In index.html, find:
<form id="rsvpForm" action="" method="POST">

Put your form endpoint inside action="...".
A service such as Formspree can provide a form endpoint, or you can connect your own Google Apps Script web app.

Until an endpoint is connected, the site runs in demo mode and stores the most recent response in the browser only. It does NOT send responses to you.

IMPORTANT:
For real guest responses, connect the form to an online endpoint before publishing the invitation link.
